# Library Management System

## Stack
- Frontend: HTML, CSS, Vanilla JavaScript
- Backend: Node.js + Express
- Database: MySQL

## Features
- Dashboard statistics
- Add/delete books
- Add/delete members
- Search books
- Issue books
- Return books
- Loan history
- Copy availability tracking

## Setup
1. Install Node.js and MySQL.
2. Create the database by running `schema.sql` in MySQL.
3. Copy `.env.example` to `.env` and set your MySQL password.
4. In this folder run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.
