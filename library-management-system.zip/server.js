require('dotenv').config();
const express = require('express');
const path = require('path');
const mysql = require('mysql2/promise');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'library_db',
  waitForConnections: true,
  connectionLimit: 10
});

app.get('/api/dashboard', async (req,res)=>{
  try {
    const [[books]] = await pool.query('SELECT COUNT(*) count, COALESCE(SUM(total_copies),0) total, COALESCE(SUM(available_copies),0) available FROM books');
    const [[members]] = await pool.query('SELECT COUNT(*) count FROM members');
    const [[loans]] = await pool.query("SELECT COUNT(*) count FROM loans WHERE status='issued'");
    res.json({books,members,issued:loans.count});
  } catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/books', async (req,res)=>{
  try { const [rows] = await pool.query('SELECT * FROM books ORDER BY id DESC'); res.json(rows); }
  catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/books', async (req,res)=>{
  const {title,author,isbn,category,total_copies} = req.body;
  if(!title || !author || !Number.isInteger(+total_copies) || +total_copies < 1) return res.status(400).json({error:'Title, author and valid copies are required'});
  try {
    const [r] = await pool.query('INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES(?,?,?,?,?,?)',[title,author,isbn||null,category||null,+total_copies,+total_copies]);
    res.json({id:r.insertId,message:'Book added'});
  } catch(e){res.status(400).json({error:e.code==='ER_DUP_ENTRY'?'ISBN already exists':e.message});}
});

app.delete('/api/books/:id', async (req,res)=>{
  try { await pool.query('DELETE FROM books WHERE id=?',[req.params.id]); res.json({message:'Book deleted'}); }
  catch(e){res.status(400).json({error:'Book cannot be deleted while loan records reference it'});}
});

app.get('/api/members', async (req,res)=>{
  try { const [rows] = await pool.query('SELECT * FROM members ORDER BY id DESC'); res.json(rows); }
  catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/members', async (req,res)=>{
  const {name,email,phone} = req.body;
  if(!name || !email) return res.status(400).json({error:'Name and email are required'});
  try { const [r]=await pool.query('INSERT INTO members(name,email,phone) VALUES(?,?,?)',[name,email,phone||null]); res.json({id:r.insertId,message:'Member added'}); }
  catch(e){res.status(400).json({error:e.code==='ER_DUP_ENTRY'?'Email already exists':e.message});}
});

app.delete('/api/members/:id', async (req,res)=>{
  try { await pool.query('DELETE FROM members WHERE id=?',[req.params.id]); res.json({message:'Member deleted'}); }
  catch(e){res.status(400).json({error:'Member cannot be deleted while loan records reference them'});}
});

app.get('/api/loans', async (req,res)=>{
  try {
    const [rows]=await pool.query(`SELECT l.*,b.title book_title,m.name member_name,m.email
      FROM loans l JOIN books b ON b.id=l.book_id JOIN members m ON m.id=l.member_id ORDER BY l.id DESC`);
    res.json(rows);
  } catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/loans', async (req,res)=>{
  const {book_id,member_id,due_date}=req.body;
  if(!book_id||!member_id||!due_date) return res.status(400).json({error:'Book, member and due date are required'});
  const conn=await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[book]]=await conn.query('SELECT available_copies FROM books WHERE id=? FOR UPDATE',[book_id]);
    if(!book) throw new Error('Book not found');
    if(book.available_copies<1) throw new Error('No available copy of this book');
    const [[member]]=await conn.query('SELECT id FROM members WHERE id=?',[member_id]);
    if(!member) throw new Error('Member not found');
    const [[existing]]=await conn.query("SELECT id FROM loans WHERE book_id=? AND member_id=? AND status='issued'",[book_id,member_id]);
    if(existing) throw new Error('This member already has this book issued');
    await conn.query("INSERT INTO loans(book_id,member_id,issue_date,due_date,status) VALUES(?,?,CURDATE(),?,'issued')",[book_id,member_id,due_date]);
    await conn.query('UPDATE books SET available_copies=available_copies-1 WHERE id=?',[book_id]);
    await conn.commit(); res.json({message:'Book issued'});
  } catch(e){await conn.rollback();res.status(400).json({error:e.message});} finally {conn.release();}
});

app.put('/api/loans/:id/return', async (req,res)=>{
  const conn=await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[loan]]=await conn.query("SELECT * FROM loans WHERE id=? FOR UPDATE",[req.params.id]);
    if(!loan) throw new Error('Loan not found');
    if(loan.status==='returned') throw new Error('Book already returned');
    await conn.query("UPDATE loans SET status='returned',return_date=CURDATE() WHERE id=?",[req.params.id]);
    await conn.query('UPDATE books SET available_copies=available_copies+1 WHERE id=?',[loan.book_id]);
    await conn.commit(); res.json({message:'Book returned'});
  } catch(e){await conn.rollback();res.status(400).json({error:e.message});} finally {conn.release();}
});

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Library Management System running at http://localhost:${PORT}`));
