# Function Hall Management System
1. Install Node.js 18+ and MySQL 8+.
2. Run database/function_hall.sql in MySQL.
3. Copy .env.example to .env and set your MySQL password.
4. Run `npm install`.
5. Run `npm start`.
6. Open http://localhost:3000
Demo login: admin@hall.com / admin123
Features: dashboard, halls, customers, bookings, date conflict checking, booking status, payments, balance calculation and printable reports.

## Payment section
The application now includes a dedicated Payments page showing all payments with booking, customer, date, amount, method and notes. Payments entered from a booking automatically update the booking's advance and balance.
